# for yeast

SDN2GO for yeast

# scripts
yeast_validation.py - This script is used to build and train the model and evaluate the performance of the model.
yeast_nodom_val.py - This script is used to build and train the model without domain features.

# data

The ‘data’ folder contains the data files that the script depends on
